employees = [
    [101, "Alice", 55000, "HR"],
    [102, "Bob", 60000, "IT"],
    [103, "Charlie", 65000, "Finance"],
    [104, "David", 70000, "IT"]
]
emp_dict = {emp[0]: {"Name": emp[1], "Salary": emp[2], "Dept": emp[3]} for emp in employees}
print(emp_dict)




# --- Strings ---
dept = "Engineering"
print("Department:", dept)
print("First 3 letters:", dept[:3])       # slicing
print("Uppercase:", dept.upper())
print("Replace g->G:", dept.replace("g", "G"))
print()

'''--- Mutability & Performance ---
# List (mutable) vs Tuple (immutable)
list_demo = [1, 2, 3]
tuple_demo = (1, 2, 3)
list_demo.append(4)   # works
print("Mutable List after append:", list_demo)
tuple_demo.append(4)  
print("Immutable Tuple stays same:", tuple_demo)
print()'''

#-----Error Handling----

# List (mutable) vs Tuple (immutable)

list_demo = [1, 2, 3]
tuple_demo = (1, 2, 3)
list_demo.append(4)   # works
print("Mutable List after append:", list_demo)
# Error handling for tuple append
try:
    tuple_demo.append(4)   # This will raise AttributeError
except AttributeError as e:
    print("Error:", e)
print("Immutable Tuple stays same:", tuple_demo)

