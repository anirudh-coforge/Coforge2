from pyspark.sql import SparkSession
# Create Spark Session
spark = SparkSession.builder.appName("LocalSparkSetup").master("local[*]").getOrCreate()
# Print Spark version
print("Spark version:", spark.version)
# Stop Spark session when done
spark.stop()
