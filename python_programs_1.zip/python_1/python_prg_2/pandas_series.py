import pandas as pd
ds=pd.Series([10, 20, 30]).mean()
print(ds)
