import pytest
from shapes import calculate_area

def test_circle_area():
    assert round(calculate_area("circle", radius=2), 2) == 12.57

def test_rectangle_area():
    assert calculate_area("rectangle", length=4, width=5) == 20

def test_invalid_shape():
    with pytest.raises(ValueError):
        calculate_area("hexagon", side=2)
