'''import numpy as np

# Create NumPy array
salaries = np.array([35000, 42000, 50000, 60000, 75000])

# Bonus calculation (vectorized)
bonus = salaries * 0.1
final_salary = salaries + bonus

print("Original Salaries:", salaries)
print("Final Salaries with Bonus:", final_salary)'''


import numpy as np
# Create 2D NumPy array -> [EmpID, Salary]
employees = np.array(
    [[1, 35000],
    [2, 42000],
    [3, 50000],
    [4, 60000],
    [5, 75000]
])
print("Original Data:\n", employees)
salaries = employees[:, 1]
print(salaries)
bonus = salaries * 0.2
final_salary = salaries + bonus
result = np.column_stack((employees, bonus, final_salary)).astype(int)

print("\nFinal Result with Bonus:\n", result)
