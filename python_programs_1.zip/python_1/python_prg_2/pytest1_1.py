def add_bonus(salary, percent):
    """Calculate bonus on salary"""
    return salary + (salary * percent / 100)
