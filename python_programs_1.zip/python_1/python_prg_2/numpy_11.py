'''import numpy as np

salaries = np.array([35000, -42000, 50000, 60000, -75000])
salaries[salaries < 0] = np.mean(salaries[salaries > 0])
print("Clean Salaries:", salaries)'''

import pandas as pd
# Create DataFrame
data = {
    "EmpID": [101, 102, 103],
    "Name": ["Raj", "Neha", "Amit"],
    "Salary": [40000, 55000, 30000]
}
df = pd.DataFrame(data)

print(df)

