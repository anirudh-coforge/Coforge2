import pandas as pd
df = pd.read_csv("employees_dirty.csv")
print("Original Data:\n", df)

# Strip spaces from Name column
df["Name"] = df["Name"].str.strip()
df["Salary"] = pd.to_numeric(df["Salary"], errors="coerce")
df["Name"].fillna("Unknown", inplace=True)
df["Department"].fillna("General", inplace=True)
df["Salary"].fillna(df["Salary"].mean(), inplace=True)

print("\nCleaned Data:\n", df)

#the parameter errors tells Pandas what to do if it finds
#values that cannot be converted to numbers.

#errors='raise' (default) → throws an error if conversion fails.
#errors='ignore' → leaves the value as it is (string, NaN, etc.).
#errors='coerce' → forces invalid values to become NaN (Not a Number).


