import pandas as pd

# Sample DataFrame
data = {'values': [74, 88, 78, 90, 94, 90, 84, 90, 98, 80, 50, 120]}
df = pd.DataFrame(data)

# Calculate Q1, Q3, and IQR
Q1 = df['values'].quantile(0.25)
Q3 = df['values'].quantile(0.75)
IQR = Q3 - Q1

# Calculate the outlier boundaries
lower_bound = Q1 - (1.5 * IQR)
upper_bound = Q3 + (1.5 * IQR)

# Filter out the outliers
df_cleaned = df[(df['values'] >= lower_bound) & (df['values'] <= upper_bound)]

print("Original DataFrame:")
print(df)
print("\nCleaned DataFrame (Outliers Removed):")
print(df_cleaned)
