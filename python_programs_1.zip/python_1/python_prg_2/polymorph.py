class OracleETL:
    def extract(self):
        print("Extracting data from Oracle DB")

class MySQLETL:
    def extract(self):
        print("Extracting data from MySQL DB")

def run_pipeline(pipeline):
    pipeline.extract()

run_pipeline(OracleETL())
run_pipeline(MySQLETL())
