import pandas as pd
import numpy as np

rows = 10**7   # 10 million rows (~1 GB depending on columns)
df = pd.DataFrame({
    "EmpID": np.arange(1, rows+1),
    "Name": np.random.choice(["Raj", "Asha", "Nisha", "Amit", "Vikram"], size=rows),
    "Department": np.random.choice(["IT", "HR", "Sales", "Finance"], size=rows),
    "Salary": np.random.randint(20000, 100000, size=rows)
})

df.to_csv("big_employees.csv", index=False)
