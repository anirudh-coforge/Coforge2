'''salaries = eval(input("Enter list of salaries: "))   # [25000, 45000, 75000, 90000]
# Empty list to store calculated bonuses
bonuses = []

# Loop through salaries and calculate bonus
for salary in salaries:
    if salary < 40000:
        bonus = salary * 0.20
    elif 40000 <= salary <= 60000:
        bonus = salary * 0.15
    elif 60001 <= salary <= 80000:
        bonus = salary * 0.10
    else:
        bonus = salary * 0.05
    
    bonuses.append(bonus)   # append bonus to list

# Display results
print("Salaries:", salaries)
print("Bonuses :", bonuses)'''


employees = [
    {"EmpID": 101, "Name": "Alice", "Salary": 35000},
    {"EmpID": 102, "Name": "Bob", "Salary": 55000},
    {"EmpID": 103, "Name": "Charlie", "Salary": 75000},
    {"EmpID": 104, "Name": "David", "Salary": 90000}
]

# Transform using while loop
i = 0
transformed = []   # to hold new records

while i < len(employees):
    emp = employees[i]
    salary = emp["Salary"]

    # Bonus calculation rules
    if salary < 40000:
        bonus = salary * 0.20
    elif 40000 <= salary <= 60000:
        bonus = salary * 0.15
    elif 60001 <= salary <= 80000:
        bonus = salary * 0.10
    else:
        bonus = salary * 0.05

    emp["Bonus"] = bonus
    transformed.append(emp)

    i += 1   # move to next record

# Load (printing or saving to file)
print("Transformed Data:")
for row in transformed:
    print(row)
