from transformations import clean_salary

print(clean_salary("60,000"))


# Example: Org chart stored in a dict
org = {
    "CEO": ["Manager1", "Manager2"],
    "Manager1": ["Dev1", "Dev2"],
    "Manager2": ["Dev3"]
}

def print_hierarchy(manager, level=0):
    print("  " * level + manager)
    if manager in org:
        for emp in org[manager]:
            print_hierarchy(emp, level+1)

print_hierarchy("CEO")

