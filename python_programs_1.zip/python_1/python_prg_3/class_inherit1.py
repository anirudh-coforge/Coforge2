class EmployeeETL:
    def __init__(self, input_file, output_file):   # Constructor
        self.input_file = input_file
        self.output_file = output_file
        self.data = []

    def extract(self):
        """Extract step (simulate by reading file lines)"""
        with open(self.input_file, "r") as f:
            self.data = [line.strip().split(",") for line in f.readlines()]
        print("[EXTRACT] Data extracted:", self.data)

class BonusETL(EmployeeETL):   # Inherits from EmployeeETL
    def transform(self):
        """Add bonus calculation"""
        transformed = []
        for row in self.data:
            emp_id, name, salary = row
            salary = int(salary)
            bonus = salary * 0.1
            transformed.append([emp_id, name, salary, bonus])
        self.data = transformed
        print("[TRANSFORM] Bonus added:", self.data)

etl = BonusETL("employees.csv", "employees_bonuss.csv")
etl.extract()
etl.transform()
