import csv
class EmployeeETL:
    def __init__(self, input_file, output_file):
        self.input_file = input_file      # Public variable
        self._data = []                   # Protected variable
        self.__output_file = output_file  # Private variable

    def extract(self):   # Public method
        """Extract: Load data from CSV"""
        with open(self.input_file, "r") as f:
            reader = csv.DictReader(f)
            self._data = list(reader)     # Store in protected variable
        print("[EXTRACT] Data extracted")

    def _transform(self):   # Protected method
        """Transform: Add bonus based on salary"""
        for row in self._data:
            salary = int(row["Salary"])
            if salary < 6000:
                row["Bonus"] = salary * 0.1
            else:
                row["Bonus"] = salary * 0.2
        print("[TRANSFORM] Data transformed")

    def __load(self):   # Private method
        """Load: Save transformed data to new CSV"""
        with open(self.__output_file, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=self._data[0].keys())
            writer.writeheader()
            writer.writerows(self._data)
        print("[LOAD] Data loaded to file")

    def run(self):   # Public method to run ETL
        self.extract()
        self._transform()
        self.__load()
        print("[RUN] ETL Complete")


