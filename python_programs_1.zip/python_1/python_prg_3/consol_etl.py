# Console ETL: Read salary and calculate bonus
salary = int(input("Enter Employee Salary: "))

if salary < 40000:
    bonus = salary * 0.2
else:
    bonus = salary * 0.1

print(f"Final Salary after bonus: {salary + bonus}")

'''
Run in terminal:
python consol_etl.py
enter employee salary: 8000
'''
