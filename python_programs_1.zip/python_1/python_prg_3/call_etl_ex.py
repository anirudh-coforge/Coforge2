from etl_ex import *
data = load_csv("employees.csv")
transformed = transform_data(data)
save_csv(transformed, "employees_with_bonus.csv")

print("ETL Complete: employees_with_bonus.csv created.")
