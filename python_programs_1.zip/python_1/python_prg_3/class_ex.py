class DataValidationError(Exception):
    pass

def validate_salary(salary):
    if salary < 0:
        raise DataValidationError("Salary cannot be negative!")
    return salary

try:
    print(validate_salary(-5000))
except DataValidationError as e:
    print("Error:", e)


