from class_ex_etl import EmployeeETL
etl = EmployeeETL("employees.csv", "employees_class_bonus.csv")

etl.extract()        # Public - works
etl._transform()     #  Works, but not recommended
#etl.__load()       #Error (private)
etl.run()  
