class EmployeeETL:
    def transform(self, records):
        for row in records:
            salary = int(row["Salary"])
            if salary < 40000:
                row["Bonus"] = salary * 0.2
            else:
                row["Bonus"] = salary * 0.1
        return records
class ITEmployeeETL(EmployeeETL):   # Inheriting
    def transform(self, records):
        for row in records:
            salary = int(row["Salary"])
            if row["Department"] == "IT":   # Override rule
                row["Bonus"] = salary * 0.25
            else:
                super().transform([row])    # Call parent for others
        return records
records = [
    {"EmpID": "1", "Name": "Raj", "Department": "IT", "Salary": "50000"},
    {"EmpID": "2", "Name": "Asha", "Department": "HR", "Salary": "30000"},
    {"EmpID": "3", "Name": "Nisha", "Department": "Sales", "Salary": "30000"},
]
etl = ITEmployeeETL()
print(etl.transform(records))
