class EmployeeETL:
    def transform(self, records):
        for row in records:
            salary = int(row["Salary"])
            if salary < 40000:
                bonus = salary * 0.2
            else:
                bonus = salary * 0.1
            row["Salary"] = salary + bonus  
        return records

class ITEmployeeETL(EmployeeETL):   
    def transform(self, records):
        for row in records:
            salary = int(row["Salary"])
            if row["Department"] == "IT":   
                bonus = salary * 0.25
                row["Salary"] = salary + bonus  
            else:
                super().transform([row])    
        return records


records = [
    {"EmpID": "1", "Name": "Raj", "Department": "IT", "Salary": "50000"},
    {"EmpID": "2", "Name": "Asha", "Department": "HR", "Salary": "30000"},
    {"EmpID": "3", "Name": "Nisha", "Department": "Sales", "Salary": "30000"},
]

etl = ITEmployeeETL()
print(etl.transform(records))
