from tabulate import tabulate
employees = [
    [101, "Aly", 40000, "HR"],
    [102, "Bobby", 55000, "IT"],
    [103, "Charles", 70000, "Finance"]
]

print(tabulate(employees, headers=["ID", "Name", "Salary", "Dept"], tablefmt="grid"))
