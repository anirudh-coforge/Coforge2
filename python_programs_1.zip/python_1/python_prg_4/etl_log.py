import csv
import logging
# Configure logger
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename="etl.log",
    filemode="w"
)

def load_csv(file_path):
    """Extract: Load data from CSV"""
    try:
        with open(file_path, "r") as f:
            reader = csv.DictReader(f)
            logging.info(f"Loaded {file_path} successfully")
            return list(reader)
    except Exception as e:
        logging.error(f"Failed to load {file_path}: {e}")
        return []

def transform_data(records):
    """Transform: Add bonus based on salary"""
    transformed = []
    for row in records:
        try:
            salary = int(row["Salary"])
            if salary < 40000:
                row["Bonus"] = salary * 0.2
            elif 40000 <= salary <= 60000:
                row["Bonus"] = salary * 0.15
            elif 60001 <= salary <= 80000:
                row["Bonus"] = salary * 0.10
            else:
                row["Bonus"] = salary * 0.05
            transformed.append(row)
            logging.debug(f"Transformed row: {row}")
        except Exception as e:
            logging.warning(f"Skipping row due to error: {e}")
    return transformed

def save_csv(records, file_path):
    """Load: Save transformed data to new CSV"""
    try:
        with open(file_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=records[0].keys())
            writer.writeheader()
            writer.writerows(records)
        logging.info(f"Saved transformed data to {file_path}")
    except Exception as e:
        logging.error(f"Failed to save {file_path}: {e}")

# ETL Execution
data = load_csv("employees.csv")
if data:
    transformed = transform_data(data)
    save_csv(transformed, "employees_with_bonus1.csv")
    logging.info("ETL pipeline completed successfully")
else:
    logging.critical("ETL pipeline aborted - No data loaded")
