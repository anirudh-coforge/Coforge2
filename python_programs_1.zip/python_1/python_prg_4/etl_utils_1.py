def add_bonus(salary, percent):
    """Calculate bonus on salary"""
    return salary + (salary * percent / 100)



def clean_salary(salary_str):
    """Remove commas and convert to int"""
    return int(salary_str.replace(",", ""))
