import json
import random
from datetime import datetime, timedelta
from pathlib import Path

OUT_FILE = "employees_1m.jsonl"
N = 1_000_000

FIRST_NAMES = ["Raj", "Asha", "Nisha", "Amit", "Vikram", "Meena", "Anil", "Pooja", "Ramesh", "Kiran"]
DEPTS = [
    {"Name": "IT", "Location": "Delhi"},
    {"Name": "HR", "Location": "Mumbai"},
    {"Name": "Finance", "Location": "Bengaluru"},
    {"Name": "Sales", "Location": "Pune"},
    {"Name": "Ops", "Location": "Hyderabad"},
]

def rand_date(start_year=2018, end_year=2025):
    start = datetime(start_year, 1, 1)
    end   = datetime(end_year, 12, 31)
    delta = end - start
    return (start + timedelta(days=random.randint(0, delta.days))).strftime("%Y-%m-%d")

def make_projects(emp_id):
    k = random.randint(0, 3)  # 0-3 projects
    projects = []
    for i in range(k):
        pid = emp_id * 10_000 + i
        projects.append({"ProjectID": pid, "Title": random.choice(["Migration", "Automation", "Analytics", "Upgrade"])})
    return projects

def main():
    Path(OUT_FILE).unlink(missing_ok=True)
    with open(OUT_FILE, "w", encoding="utf-8") as f:
        for emp_id in range(1, N + 1):
            rec = {
                "EmpID": emp_id,
                "Name": random.choice(FIRST_NAMES),
                "Dept": random.choice(DEPTS),
                "Projects": make_projects(emp_id),
                "Salary": random.randint(20000, 150000),
                "HiredAt": rand_date()
            }
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            if emp_id % 100_000 == 0:
                print(f"[GEN] wrote {emp_id:,} records")
    print(f"Done. File: {OUT_FILE}")

if __name__ == "__main__":
    main()
