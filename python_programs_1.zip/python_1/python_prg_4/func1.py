def clean_salary(salary_str):
    salary_str = salary_str.replace(",", "").replace("$", "").lower()
    if "k" in salary_str:
        return int(salary_str.replace("k", "")) * 1000
    return int(salary_str)

# Example raw data
salaries = ["60,000", "$70000", "85k", "45000"]

cleaned_salaries = [clean_salary(s) for s in salaries]
print("Cleaned Salaries:", cleaned_salaries)



from datetime import datetime

def clean_timestamp(date_str):
    formats = ["%d-%m-%Y", "%Y/%m/%d", "%m-%d-%Y", "%d %b %Y"]
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None   # return None if no format matches

# Example raw data
dates = ["25-08-2025", "2025/08/25", "08-25-2025", "25 Aug 2025"]

cleaned_dates = [clean_timestamp(d) for d in dates]
print("Cleaned Dates:", cleaned_dates)
