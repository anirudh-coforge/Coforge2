# transformations.py
def clean_salary(salary_str):
    """Convert salary string to integer"""
    return int(salary_str.replace(",", ""))

