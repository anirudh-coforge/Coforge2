import requests
import pandas as pd
import numpy as np
from sqlalchemy import create_engine, text

# API SETUP -------------------
url = "https://api.coingecko.com/api/v3/coins/markets"
params = {
    "vs_currency": "usd",
    "order": "market_cap_desc",
    "per_page": 50,
    "page": 1,
    "sparkline": False
}

# FETCH MULTIPLE PAGES -------------------
all_data = []
for page in range(1, 6):  # 5 pages × 50 = 250 rows
    params["page"] = page
    response = requests.get(url, params=params)
    if response.status_code == 200:
        page_data = response.json()
        all_data.extend(page_data)
        print(f"Page {page} fetched: {len(page_data)} rows")
    else:
        print(f"Failed to fetch page {page}: {response.status_code}")

# Convert JSON → DataFrame
df = pd.json_normalize(all_data)
print(f"Total rows fetched: {len(df)}")

#  TRANSFORMATION -------------------
# Drop duplicates
df = df.drop_duplicates(subset="id")

# Add calculated columns
df["price_log"] = df["current_price"].apply(lambda x: np.log(x) if x and x > 0 else None)
df["volume_normalized"] = (
    (df["total_volume"] - df["total_volume"].mean()) / df["total_volume"].std()
)

print("Transformations applied")
print(df.head(5))

# DATABASE CONNECTIONS -------------------
# MS SQL (Windows Auth)
mssql_engine = create_engine(
    "mssql+pyodbc:///?odbc_connect="
    "Driver={ODBC Driver 17 for SQL Server};"
    "Server=localhost\\SQLEXPRESS;"
    "Database=cryptodb;"
    "Trusted_Connection=yes;"
)

# (Optional) MySQL connection (uncomment if MySQL is running)
# mysql_engine = create_engine("mysql+mysqlconnector://root:password@localhost:3306/cryptodb")

#  LOAD INTO DATABASE -------------------
# Insert into MS SQL
df.to_sql("crypto_data", mssql_engine, if_exists="replace", index=False)
print("Data inserted into MS SQL")

# Insert into MySQL (optional)
# df.to_sql("crypto_data", mysql_engine, if_exists="replace", index=False)
# print(" Data inserted into MySQL")

#  VERIFY -------------------
with mssql_engine.connect() as conn:
    result = conn.execute(text("SELECT COUNT(*) FROM crypto_data"))
    print("MS SQL row count:", result.scalar())
