import sys
import io

# Simulate: cat employees.csv |
sys.stdin = open("employees.csv", "r")

# Simulate: > employees_with_bonus.csv
sys.stdout = open("employees_with_bonus.csv", "w")

# Simulate: 2> etl_errors.log
sys.stderr = open("etl_errors.log", "w")

for line in sys.stdin:
    sys.stdout.write(line.upper())   # example transformation
