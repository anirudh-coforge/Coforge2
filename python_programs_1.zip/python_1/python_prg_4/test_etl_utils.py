# test_etl_utils.py
from etl_utils import add_bonus

def test_add_bonus():
    assert add_bonus(1000, 10) == 1100
