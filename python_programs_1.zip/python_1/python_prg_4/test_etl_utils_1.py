from etl_utils_1 import add_bonus
def test_add_bonus():
    assert add_bonus(1000, 10) == 1100   # Expected pass
    assert add_bonus(2000, 20) == 2400   # Expected pass
    assert add_bonus(2100, 20) == 2400
