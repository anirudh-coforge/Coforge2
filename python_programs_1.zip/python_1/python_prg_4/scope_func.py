tax_rate = 0.1                      # Global scope
def calculate_tax(amount):
    local_discount = 0.05           # Local scope
    return amount - (amount * local_discount) + (amount * tax_rate)

print(calculate_tax(1000))          # 1050.0



