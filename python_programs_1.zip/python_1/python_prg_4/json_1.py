import json
import pandas as pd
from sqlalchemy import create_engine
from pandas import json_normalize

JSONL_FILE = "employees_1m.jsonl"
CHUNK = 50_000  # tune based on memory/IO
MSSQL_CONN = (
    "mssql+pyodbc://@localhost\SQLEXPRESS/ETLDB?driver=ODBC+Driver+17+for+SQL+Server&Trusted_Connection=yes"
)
EMP_TABLE = "dbo.Employees"
PRJ_TABLE = "dbo.Projects"

engine = create_engine(MSSQL_CONN, fast_executemany=True)

def process_batch(lines):
    records = [json.loads(l) for l in lines]
    df_emp = json_normalize(records, sep="_")
    df_emp = df_emp[["EmpID", "Name", "Dept_Name", "Dept_Location", "Salary", "HiredAt"]]
    df_prj = json_normalize(records, record_path="Projects", meta=["EmpID"], sep="_")
    if df_prj.empty:
        df_prj = pd.DataFrame(columns=["ProjectID", "Title", "EmpID"])
    df_emp["EmpID"] = df_emp["EmpID"].astype("int64")
    df_emp["Salary"] = pd.to_numeric(df_emp["Salary"], errors="coerce").astype("Int64")
    df_emp["HiredAt"] = pd.to_datetime(df_emp["HiredAt"], errors="coerce").dt.date
    if not df_prj.empty:
        df_prj["EmpID"] = df_prj["EmpID"].astype("int64")
        df_prj["ProjectID"] = pd.to_numeric(df_prj["ProjectID"], errors="coerce").astype("Int64")
    return df_emp, df_prj

def main():
    total = 0
    with open(JSONL_FILE, "r", encoding="utf-8") as f:
        batch = []
        for line in f:
            if line.strip():
                batch.append(line)
            if len(batch) >= CHUNK:
                df_emp, df_prj = process_batch(batch)
                df_emp.to_sql(EMP_TABLE, engine, if_exists="append", index=False)
                if not df_prj.empty:
                    df_prj.to_sql(PRJ_TABLE, engine, if_exists="append", index=False)
                total += len(batch)
                print(f"[LOAD] inserted {total:,} rows (employees) so far")
                batch.clear()
        if batch:
            df_emp, df_prj = process_batch(batch)
            df_emp.to_sql(EMP_TABLE, engine, if_exists="append", index=False)
            if not df_prj.empty:
                df_prj.to_sql(PRJ_TABLE, engine, if_exists="append", index=False)
            total += len(batch)
            print(f"[LOAD] inserted {total:,} rows total")
    print("Done.")

if __name__ == "__main__":
    main()
