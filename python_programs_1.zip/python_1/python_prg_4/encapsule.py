#Encapsulation (Public, Protected, Private)
#Public → Accessible everywhere (self.data)
#Protected → Prefix _, intended for child classes
#Private → Prefix __, hidden from outside
class SecureETL:
    def __init__(self, db_name):
        self.db_name = db_name          # Public
        self._connection = None         # Protected
        __password = "secret123"   # Private

    def _connect(self):   # Protected
        self._connection = f"Connected to {self.db_name}"
        print("[CONNECT] Using password hidden")
        print(self.__password)

    def __load(self):     # Private
        print("[LOAD] Data written to DB securely")

    def run(self):
        self._connect()
        self.__load()


etl = SecureETL("OracleDB")
etl.run()
# etl.__load()  # Error (private)
