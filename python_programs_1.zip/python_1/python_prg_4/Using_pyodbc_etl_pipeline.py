import requests
import pandas as pd
import numpy as np
import pyodbc   # For MS SQL
# import mysql.connector  # Uncomment if using MySQL

# -------------------- STEP 1: EXTRACT --------------------
url = "https://api.coingecko.com/api/v3/coins/markets"
params = {
    "vs_currency": "usd",
    "order": "market_cap_desc",
    "per_page": 50,
    "page": 1,
    "sparkline": "false"
}

all_data = []

for page in range(1, 6):  # 5 pages × 50 rows = 250
    params["page"] = page
    response = requests.get(url, params=params)
    page_data = response.json()
    all_data.extend(page_data)
    print(f"Page {page} fetched: {len(page_data)} rows")

df = pd.json_normalize(all_data)
print(f"Total rows fetched: {len(df)}")


# -------------------- STEP 2: TRANSFORM --------------------
# Handle missing values
df = df.fillna({
    "current_price": 0,
    "market_cap": 0,
    "total_volume": 0
})

# Detect outliers in 'current_price' using z-score
df["z_score_price"] = (df["current_price"] - df["current_price"].mean()) / df["current_price"].std()
outliers = df[df["z_score_price"].abs() > 3]
print(f"Found {len(outliers)} price outliers")

# Normalize 'market_cap' and 'total_volume'
df["market_cap_norm"] = (df["market_cap"] - df["market_cap"].min()) / (df["market_cap"].max() - df["market_cap"].min())
df["total_volume_norm"] = (df["total_volume"] - df["total_volume"].min()) / (df["total_volume"].max() - df["total_volume"].min())

# Keep only selected columns
final_df = df[["id", "symbol", "name", "current_price", "market_cap", "total_volume",
               "market_cap_norm", "total_volume_norm"]]

print("Transform step completed")


# STEP 3: LOAD --------------------
# OPTION A: MS SQL ---
conn = pyodbc.connect(
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=localhost\\SQLEXPRESS;"   # Use \\ for instance name
    "DATABASE=CryptoDB;"
    "Trusted_Connection=yes;"
)
cursor = conn.cursor()

# Create table if not exists
cursor.execute("""

CREATE TABLE CryptoData (
    id VARCHAR(50),
    symbol VARCHAR(10),
    name VARCHAR(100),
    current_price FLOAT,
    market_cap BIGINT,
    total_volume BIGINT,
    market_cap_norm FLOAT,
    total_volume_norm FLOAT
)
""")
conn.commit()

# Insert data
for _, row in final_df.iterrows():
    cursor.execute("""
    INSERT INTO CryptoData (id, symbol, name, current_price, market_cap, total_volume, market_cap_norm, total_volume_norm)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, tuple(row))

conn.commit()
cursor.close()
conn.close()
print("Data loaded into MS SQL successfully!")
