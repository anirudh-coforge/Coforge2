import sqlite3
conn = sqlite3.connect("sales.db")
cursor = conn.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS sales (id INTEGER, product TEXT, amount REAL)")
cursor.execute("INSERT INTO sales VALUES (1, 'Laptop', 1200.50)")
conn.commit()
cursor.execute("SELECT * FROM sales")
print(cursor.fetchall())

conn.close()
