data = ["100", "200", "abc", "300"]

cleaned = []
for val in data:
    try:
        cleaned.append(int(val))
    except ValueError as e:
        print(f"Skipping invalid record: {val} - {e}")

print("Cleaned Data:", cleaned)
