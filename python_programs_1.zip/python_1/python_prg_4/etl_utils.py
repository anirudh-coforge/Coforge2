# etl_utils.py
def add_bonus(salary, percent):
    return salary + (salary * percent / 100)

