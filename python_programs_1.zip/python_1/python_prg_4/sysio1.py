import sys

for line in sys.stdin:   # Extract from stream
    try:
        emp_id, name, salary = line.strip().split(",")
        salary = int(salary)
        bonus = salary * 0.1
        sys.stdout.write(f"{emp_id},{name},{salary},{bonus}\n")   # Load clean data
    except Exception as e:
        sys.stderr.write(f"Error in line: {line} - {e}\n")       # Log errors


'''
Run in terminal
cat employees1.csv | python sysio1.py > clean_employees.csv 2> etl_errors.log
cat etl_errors.log
cat clean_employees.csv'''
