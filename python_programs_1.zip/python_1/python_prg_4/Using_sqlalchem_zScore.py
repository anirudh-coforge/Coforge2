import requests
import pandas as pd
from sqlalchemy import create_engine

# API Endpoint
url = "https://api.coingecko.com/api/v3/coins/markets"

params = {
    "vs_currency": "usd",
    "order": "market_cap_desc",
    "per_page": 50,
    "page": 1,
    "sparkline": "false"
}

response = requests.get(url, params=params)
data = response.json()

# Normalize JSON into flat DataFrame
df = pd.json_normalize(data)
print(df.head())

# Drop rows with missing values in critical fields
df = df.dropna(subset=["id", "symbol", "current_price"])

# Fill missing values in non-critical fields with defaults
df["total_volume"] = df["total_volume"].fillna(0)
#Handle Outliers (using IQR)

Q1 = df["current_price"].quantile(0.25)
Q3 = df["current_price"].quantile(0.75)
IQR = Q3 - Q1

df = df[(df["current_price"] >= Q1 - 1.5*IQR) &
        (df["current_price"] <= Q3 + 1.5*IQR)]
# Normalization (Z-score)

df["price_normalized"] = (df["current_price"] - df["current_price"].mean()) / df["current_price"].std()
# Load (MS SQL / MySQL)



# MS SQL Connection
engine_mssql = create_engine(
    "mssql+pyodbc:///?odbc_connect="
    "Driver={ODBC Driver 17 for SQL Server};"
    "Server=localhost\\SQLEXPRESS;"
    "Database=CryptoDB;"
    "Trusted_Connection=yes;"
)

# Store transformed data
df.to_sql("crypto_data_sqlalch", engine_mssql, if_exists="replace", index=False)
print("Data loaded into MS SQL")
'''
#MySQL Example
engine_mysql = create_engine("mysql+pymysql://user:password@localhost:3306/cryptodb")

df.to_sql("crypto_data", engine_mysql, if_exists="replace", index=False)

print(" Data loaded into MySQL")'''
