import sys
for line in sys.stdin:   # Read raw data from stdin
    try:
        emp_id, name, salary = line.strip().split(",")
        salary = int(salary)
        bonus = salary * 0.1
        sys.stdout.write(f"{emp_id},{name},{salary},{bonus}\n")   # Processed output
    except Exception as e:
        sys.stderr.write(f"Error processing line: {line} - {e}\n")   # Errors separate
