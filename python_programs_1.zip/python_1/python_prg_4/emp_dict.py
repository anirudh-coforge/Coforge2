employees = {
    101: {"Name": "Alice", "Salary": 55000, "Dept": "HR"},
    102: {"Name": "Bob", "Salary": 60000, "Dept": "IT"},
    103: {"Name": "Charlie", "Salary": 65000, "Dept": "Finance"},
    104: {"Name": "David", "Salary": 70000, "Dept": "IT"}
}
emp_dict = dict((emp[0], emp[1:]) for emp in employees)
print(emp_dict)

