import sqlite3
conn = sqlite3.connect('employee.db')
cursor1= conn.cursor()

cursor1.execute('''
    CREATE TABLE IF NOT EXISTS emptable (
        empid INTEGER PRIMARY KEY,
        empname TEXT NOT NULL,
        salary REAL,
        deptid TEXT,
        date_of_join TEXT
    )
''')
conn.commit()
# Get user input and insert data into the 'emptable' table
empid = int(input("Enter Employee ID: "))
empname = input("Enter Employee Name: ")
salary = float(input("Enter Salary: "))
deptid = input("Enter Department ID: ")
date_of_join = input("Enter Date of Joining (YYYY-MM-DD): ")

cursor1.execute('''
    INSERT INTO emptable (empid, empname, salary, deptid, date_of_join)
    VALUES (?, ?, ?, ?, ?)
''', (empid, empname, salary, deptid, date_of_join))
conn.commit()

print("Data inserted successfully.")


cursor1.execute("SELECT * FROM emptable")
rows = cursor1.fetchall()

print("Current Employee Records:")
for row in rows:
    print(row)
conn.close()
