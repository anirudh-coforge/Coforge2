from sqlalchemy import create_engine, Table, Column, Integer, String, Float, MetaData

class ProductDB:
    def __init__(self, connection_string):
        # Create engine and metadata
        self.engine = create_engine(connection_string)
        self.metadata = MetaData()

        # Define table
        self.products = Table("products", self.metadata,
            Column("id", Integer, primary_key=True, autoincrement=True),
            Column("name", String(50), nullable=False),
            Column("price", Float, nullable=False),
            Column("category", String(50))
        )

        # Create table if it doesn’t exist
        self.metadata.create_all(self.engine)

    def insert_product(self, name, price, category):
        # Insert with auto-commit
        with self.engine.begin() as conn:
            conn.execute(self.products.insert().values(
                name=name,
                price=price,
                category=category
            ))

    def show_products(self):
        with self.engine.connect() as conn:
            result = conn.execute(self.products.select())
            for row in result:
                print(row)

if __name__ == "__main__":
    conn_str = (
        "mssql+pyodbc://localhost\\SQLEXPRESS/CompanyDB?"
        "driver=ODBC+Driver+17+for+SQL+Server&trusted_connection=yes"
    )

    db = ProductDB(conn_str)

    while True:
        name = input("Enter product name: ")
        price = float(input("Enter product price: "))
        category = input("Enter product category: ")

        db.insert_product(name, price, category)
        print("Product inserted!")

        choice = input("Add another product? (y/n): ").strip().lower()
        if choice != "y":
            break

    print("\n Final Products in Database:")
    db.show_products()
