from sqlalchemy import create_engine, Table, Column, Integer, String, MetaData
import urllib

# URL encode the connection string
params = urllib.parse.quote_plus(
    "Driver={ODBC Driver 17 for SQL Server};"
    "Server=localhost\\SQLEXPRESS;"
    "Database=CompanyDB;"
    "Trusted_Connection=yes;"
)

engine = create_engine(f"mssql+pyodbc:///?odbc_connect={params}")
metadata = MetaData()

# Define table
employees = Table(
    "employees", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("name", String(50)),
    Column("salary", Integer)
)

metadata.create_all(engine)

# Insert data with automatic commit
with engine.begin() as conn:
    conn.execute(employees.insert().values(name="Charlie", salary=82000))

# Query data
with engine.connect() as conn:
    result = conn.execute(employees.select())
    for row in result:
        print(row)
